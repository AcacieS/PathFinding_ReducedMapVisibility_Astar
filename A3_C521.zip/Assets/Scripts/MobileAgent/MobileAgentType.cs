public enum MobileAgentType
{
    Small,
    Medium,
    Big,
}