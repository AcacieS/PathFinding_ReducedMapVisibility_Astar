public enum VertexType
{
    Exterior,
    Interior
}