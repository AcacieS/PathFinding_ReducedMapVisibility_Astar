using UnityEngine;

[CreateAssetMenu(fileName = "VertexInfo", menuName = "Scriptable Objects/VertexInfo")]
public class VertexInfo : ScriptableObject
{
    
}
